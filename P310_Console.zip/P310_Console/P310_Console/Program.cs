﻿using System;

namespace P310_Console
{
    class Program
    {
        static void Main()
        {
            //constructor
            //property

            //Person person = new Person();
            //Person person2 = new Person(new DateTime(1991, 10, 10));
            //Person person2 = new Person(new DateTime(1991, 10, 10), "Samir");
            //person.GetName(); //method overloading is static polymorphism

            Person person = new Person(new DateTime(1991, 10, 10), "Samir");

            person.Firstname = "Samir";
            Console.WriteLine(person.Firstname);
        }
    }

    class Person
    {
        //constructor is a method
        //but 
        //name should be the same as class/struct
        //no return type
        public DateTime Birthdate;
        public string Lastname;

        private string _firstname;

        public string Firstname
        {
            get { return _firstname; }
            set { _firstname = value; }
        }


        //public Person()
        //{
        //    Console.WriteLine("New person just was born");
        //}

        public Person(DateTime birthdate)
        {
            if (DateTime.Now.Year - birthdate.Year < 18)
                throw new ArgumentException("Birthdate can not be greater than today");
            Birthdate = birthdate;
        }

        public Person(DateTime bdate, string firstname) : this(bdate)
        {
            if (firstname.Length <= 2)
                throw new ArgumentException("Person firstname can not be less than 2 characters");

            //Firstname = firstname.Trim();
        }

        public Person(DateTime bdate, string firstname, string lastname) : this(bdate, firstname)
        {
            if (lastname.Length <= 2)
                throw new ArgumentException("Person firstname can not be less than 2 characters");

            Lastname = lastname.Trim();
        }

        public void GetName() { }
        public void GetName(string a) { }
        public void GetName(int b) { }
    }

    class Developer : Person
    {
        public Developer(DateTime b) : base(b)
        {
        }
    }
}
